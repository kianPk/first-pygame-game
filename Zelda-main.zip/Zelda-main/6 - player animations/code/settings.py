# game setup
WIDTH    = 300
HEIGTH   = 100
FPS      = 120
TILESIZE = 30